<?php

//koneksi
$koneksi = mysqli_connect("localhost", "n1577229_digilib_kel1", "*t3lk0m#2023", "n1577229_digilib_tk_kel1");

// $digi = new digilib;
// $koneksi = $digi->koneksi();

if (isset($_POST['p'])) {
    $p = $_POST['p'];
    if ($p == "mahasiswa") {
        $nama = $_POST['nama'];
        $q = mysqli_query($koneksi, "SELECT nim,nama,kelas FROM mahasiswa WHERE nama LIKE '%$nama%'");
        while ($d = mysqli_fetch_row($q)) {
            // $data[] = array('nim' => $d[0], 'nama' => $d[1], 'kelas' => $d[2]);
            $label = '[' . $d[2] . '] ' . $d[0] . ' ' . $d[1];
            $value = $d[0] . ' ' . $d[1];
            $data[] = array('label' => $label, 'value' => $value);
        }
        echo json_encode($data);
    }
}
?>